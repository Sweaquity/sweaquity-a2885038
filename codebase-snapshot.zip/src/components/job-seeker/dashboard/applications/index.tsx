
import { ApplicationsTabBase } from "./ApplicationsTabBase";

export { ApplicationsTabBase };
